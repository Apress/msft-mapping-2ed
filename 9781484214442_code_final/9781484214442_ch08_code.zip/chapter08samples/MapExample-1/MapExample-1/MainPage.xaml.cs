﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Services.Maps;
using Windows.Devices.Geolocation;
using Windows.UI.Xaml.Controls.Maps;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace MapExample_1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        MapIcon youAreHerePin;
        Geolocator geolocator;

        public MainPage()
        {
            this.InitializeComponent();
            map.MapElementClick += map_MapElementClick;
            Loaded += MainPage_Loaded;
        }


        private void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            geolocator = new Geolocator();
            geolocator.PositionChanged += Geolocator_PositionChanged;
            geolocator.StatusChanged += Geolocator_StatusChanged;
        }

        private void Geolocator_StatusChanged(Geolocator g, StatusChangedEventArgs e)
        {
        }

        private async void Geolocator_PositionChanged(Geolocator g,
                                                      PositionChangedEventArgs e)
        {
            await this.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
            {
                if (youAreHerePin == null)
                {
                    youAreHerePin = new MapIcon();
                    map.MapElements.Add(youAreHerePin);
                }
                Geoposition location = e.Position;
                BasicGeoposition position = new BasicGeoposition();
                position.Latitude = location.Coordinate.Latitude;
                position.Longitude = location.Coordinate.Longitude;
                position.Altitude = location.Coordinate.Altitude ?? 0;
                
                youAreHerePin.Location = new Geopoint(position);
                youAreHerePin.Title = "You Are Here";
            });
        }   

        private async void map_MapElementClick(MapControl sender, MapElementClickEventArgs args)
        {
            if (args.MapElements.Count > 0 && args.MapElements[0] is MapIcon)
            {
                MapIcon icon = (MapIcon)args.MapElements[0];

                StreetsidePanorama panorama = await StreetsidePanorama.FindNearbyAsync(icon.Location);
                if (panorama != null && map.IsStreetsideSupported)
                {
                    map.CustomExperience = new StreetsideExperience(panorama);
                }
                else
                {
                    // Indicate whether the panorama wasn't found, 
                    // or whether Streetside isn't supported.
                }
            }
        }

        private async void coffeeButton_Click(object sender, RoutedEventArgs e)
        {
            string addressToGeocode = "201 Castro St, Mountain View, CA 94041";

            MapLocationFinderResult result =
                await MapLocationFinder.FindLocationsAsync(addressToGeocode, map.Center, 3);

            if (result.Status == MapLocationFinderStatus.Success)
            {
                map.MapElements.Clear();

                foreach(MapLocation location in result.Locations)
                {
                    MapIcon icon = new MapIcon();
                    icon.Location = location.Point;
                    icon.CollisionBehaviorDesired = MapElementCollisionBehavior.RemainVisible;
                    icon.Title = "Red Rock Coffee";
                    map.MapElements.Add(icon);
                }

                if (result.Locations.Count > 0)
                {
                    await map.TrySetSceneAsync(MapScene.CreateFromLocationAndRadius(result.Locations[0].Point, 5, 0, 45));
                    /*
                    await map.TrySetViewAsync(result.Locations[0].Point,
                        16,
                        0,
                        45,
                        MapAnimationKind.Default);
                        */
                }
            }
        }

        private void modeButton_Click(object sender, RoutedEventArgs e)
        {
            if (map.Style == MapStyle.Road)
            {
                if (map.Is3DSupported)
                {
                    map.Style = MapStyle.Aerial3DWithRoads;
                }
                else
                {
                    map.Style = MapStyle.AerialWithRoads;
                }
            }
            else
            {
                map.Style = MapStyle.Road;
            }
        }

    }
}
